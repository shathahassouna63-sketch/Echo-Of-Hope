<!DOCTYPE html>
<html>
<head>
  <title>Echo of Hope</title>
  <link rel="icon" type="image/png" href="icon.png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  
  
  <!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<link rel="stylesheet" href="about.css">
</head>

</head>

<body>
<header class="navbar">
<div class="logo">Echo of Hope</div>
<nav>
<a href="sample.php">Home &gt;</a>
<a href="search.php">Search &gt;</a>
<a href="request.php">Request Help &gt;</a>
<a href="about.php">About Us &gt;</a>
<a href="contact.php">Contact &gt;</a>
<a href="donate.php">Donate &gt; </a>
</nav>
</header>

<section class="a-h">
<img src="about.jpeg" alt="About Echo of Hope">

<div class="a-b">
<h1> About Echo of Hope </h1>
<p> "Echo of Hope rose after the last lebanese to support families searching for missing beloved ones. 
We stand with you in moments of uncertainty, offering compassion, tools and hope." </p>

</div>
</section>

<section class="i-s">
<div class="i-b">
<h3> Our Mission </h3>
<p> We aim to help families find their lost beloveds and stand with them through moments of weakness and uncertainty. </p>
</div>

<div class="i-b">
<h3> What we do </h3>
<p> We connect individuals with resources, volunteers and donations to ensure no missing person stays away for long. </p>
</div>

<div class="i-b">
<h3> Our Values </h3> 
<p>  Compassion, transparency, community, and hope guide every action we take. </p>
</div> 
</section> 

<footer>
  <div class="footer-container">

    <div class="footer-section contact">
      <h3>Contact Us</h3>
      <p>123 Main Street, City, Country</p>
      <p>Phone: +961 05 432 134</p>
      <p>Email: echoofhope@outlook.com</p>
    </div>

    <div class="footer-section newsletter">
      <h3>Subscribe</h3>
      <p>Get updates and news from our organization:</p>
      <form>
        <input type="email" placeholder="Enter your email">
        <button type="submit">Subscribe</button>
      </form>
    </div>

    <div class="footer-section social">
      <h3>Follow Us</h3>
      <div class="social-icons">
        <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
        <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
        <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
      </div>
    </div>

  </div>

  <hr>

  <div class="footer-bottom">
    <p>
      <a href="#">Privacy Policy</a> | 
      <a href="#">Terms & Conditions</a> | 
      <a href="#">Accessibility</a>
    </p>
    <p>© 2026 Organization Name. All rights reserved.</p>
  </div>
</footer>



<script>
window.addEventListener("scroll", () => {
const boxes = document.querySelectorAll(".i-b");
const triggerPoint = window.innerHeight * 0.8;

boxes.forEach(box => {
const boxTop = box.getBoundingClientRect().top;

if (boxTop < triggerPoint) {
box.classList.add("show");
}
});
});
</script>

</body>
</html>

