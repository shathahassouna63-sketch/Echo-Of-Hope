<?php
session_start();
require_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $first_name = htmlspecialchars(trim($_POST['first_name']));
    $last_name = htmlspecialchars(trim($_POST['last_name']));
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $message = htmlspecialchars(trim($_POST['message']));
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['message'] = "Please enter a valid email address.";
        $_SESSION['message_type'] = 'error';
        header("Location: contact.php");
        exit;
    }
    
    if (isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])) {
        
        $recaptcha_response = $_POST['g-recaptcha-response'];
        $verify_url = "https://www.google.com/recaptcha/api/siteverify";
        
        $data = array(
            'secret' => RECAPTCHA_SECRET_KEY,
            'response' => $recaptcha_response
        );
        
        $options = array(
            'http' => array(
                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                'method' => 'POST',
                'content' => http_build_query($data)
            )
        );
        
        $context = stream_context_create($options);
        $result = file_get_contents($verify_url, false, $context);
        $response = json_decode($result);
        
        if ($response->success) {
            
            $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            
            if ($conn->connect_error) {
                $_SESSION['message'] = "Database connection failed. Please try again later.";
                $_SESSION['message_type'] = 'error';
                header("Location: contact.php");
                exit;
            }
            
            $stmt = $conn->prepare("INSERT INTO contacts (first_name, last_name, email, message) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $first_name, $last_name, $email, $message);
            
            if ($stmt->execute()) {
                $_SESSION['message'] = "Thank you for your message! We will get back to you soon.";
                $_SESSION['message_type'] = 'success';
            } else {
                $_SESSION['message'] = "Sorry, there was an error saving your message. Please try again.";
                $_SESSION['message_type'] = 'error';
            }
            
            $stmt->close();
            $conn->close();
            
        } else {
            $_SESSION['message'] = "reCAPTCHA verification failed. Please try again.";
            $_SESSION['message_type'] = 'error';
        }
        
    } else {
        $_SESSION['message'] = "Please complete the reCAPTCHA verification.";
        $_SESSION['message_type'] = 'error';
    }
    
} else {
    $_SESSION['message'] = "Invalid request.";
    $_SESSION['message_type'] = 'error';
}

header("Location: contact.php");
exit;
?>
