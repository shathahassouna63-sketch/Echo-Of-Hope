<?php
require_once 'config.php';

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM contacts ORDER BY created_at DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>View Messages | Echo of Hope</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        body {
            background-color: #f7f7f7;
            padding: 20px;
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }
        h1 {
            color: #6b1f57;
            margin-bottom: 30px;
        }
        .message-card {
            background: #f8f9fa;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            border-left: 4px solid #3498db;
        }
        .message-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            flex-wrap: wrap;
        }
        .message-name {
            font-weight: bold;
            color: #6b1f57;
            font-size: 18px;
        }
        .message-email {
            color: #666;
        }
        .message-date {
            color: #999;
            font-size: 14px;
        }
        .message-text {
            margin-top: 15px;
            padding: 15px;
            background: white;
            border-radius: 6px;
            line-height: 1.6;
        }
        .no-messages {
            text-align: center;
            padding: 40px;
            color: #999;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #3498db;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="contact.php" class="back-link">← Back to Contact Page</a>
        <h1>Contact Messages</h1>
        
        <?php if ($result->num_rows > 0): ?>
            <p style="color: #666; margin-bottom: 20px;">Total messages: <?php echo $result->num_rows; ?></p>
            
            <?php while($row = $result->fetch_assoc()): ?>
                <div class="message-card">
                    <div class="message-header">
                        <div>
                            <div class="message-name"><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></div>
                            <div class="message-email"><?php echo htmlspecialchars($row['email']); ?></div>
                        </div>
                        <div class="message-date">
                            <?php echo date('F j, Y, g:i a', strtotime($row['created_at'])); ?>
                        </div>
                    </div>
                    <div class="message-text">
                        <?php echo nl2br(htmlspecialchars($row['message'])); ?>
                    </div>
                </div>
            <?php endwhile; ?>
            
        <?php else: ?>
            <div class="no-messages">
                <p>No messages yet.</p>
                <p>Messages will appear here once someone submits the contact form.</p>
            </div>
        <?php endif; ?>
    </div>
    
    <?php
    $conn->close();
    ?>
</body>
</html>
