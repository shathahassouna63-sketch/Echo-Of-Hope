-- Database Setup SQL File
-- 
-- This file contains SQL commands to create the database and table.
-- You can run this in phpMyAdmin or MySQL command line.
--
-- Instructions:
-- 1. Open phpMyAdmin (usually at http://localhost/phpmyadmin)
-- 2. Click on "SQL" tab
-- 3. Copy and paste the commands below
-- 4. Click "Go"

-- Create database
CREATE DATABASE IF NOT EXISTS echo_of_hope;

-- Use the database
USE echo_of_hope;

-- Create contacts table
CREATE TABLE IF NOT EXISTS contacts (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- That's it! Your database is ready to use.

