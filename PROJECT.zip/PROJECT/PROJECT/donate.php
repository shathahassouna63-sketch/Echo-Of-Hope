<!DOCTYPE html>
<html>
<head>
    <title>Echo of Hope</title>
	<link rel="icon" type="image/png" href="icon.png">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
	
	<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<link rel="stylesheet" href="donate.css">
</head>

</head>
<body>

<header class="navbar">
<div class="logo">Echo of Hope</div>
<nav>
<a href="sample.php">Home &gt;</a>
<a href="search.php">Search &gt;</a>
<a href="request.php">Request Help &gt;</a>
<a href="about.php">About Us &gt;</a>
<a href="contact.php">Contact &gt;</a>
<a href="donate.php">Donate &gt; </a>
</nav>
</header>

<div class="donation-box">

    <h1>Thank You for Making a Change</h1>

    <p class="p1">
        Your donation helps reunite lost people with their families and brings hope to those who need it most.
    </p>

    <p class="highlight">
        A small amount makes a big difference. Thank you.
    </p>

    <h2>Select Currency</h2>
    <div class="options">
        <label><input type="radio" name="currency" checked> USD ($)</label>
        <label><input type="radio" name="currency"> EUR (€)</label>
        <label><input type="radio" name="currency"> Other</label>
    </div>

    <h2>Donation Amount</h2>
    <input type="number" placeholder="Enter amount" class="input-field">

    <h2>Payment Method</h2>
    <div class="payment-methods">

        <label class="payment-option visa">
            <input type="radio" name="payment" checked>
            <i class="fa-brands fa-cc-visa"></i>
            Visa
        </label>

        <label class="payment-option paypal">
            <input type="radio" name="payment">
            <i class="fa-brands fa-paypal"></i>
            PayPal
        </label>

        <label class="payment-option wish">
            <input type="radio" name="payment">
            <i class="fa-solid fa-wallet"></i>
            Wish
        </label>

    </div>

    <h2>Payment Details</h2>
    <input type="text" placeholder="Cardholder Name" class="input-field">
    <input type="text" placeholder="Card Number" class="input-field">

    <div class="row">
        <input type="text" placeholder="MM/YY" class="input-field small">
        <input type="text" placeholder="CVV" class="input-field small">
    </div>

    <button class="donate-btn" onclick="showThankYou()">Donate Securely</button>

    <p class="secure">
        🔒 Your payment information is safe and encrypted.
    </p>

</div>

<div id="thankYouPopup" class="thank-you-popup">
    <div id="confetti-container"></div>
    <div class="thank-you-card">
        <div class="thank-you-icon">✓</div>
        <h2>Thank You for Your Donation!</h2>
        <p>Your generosity helps us reunite families and bring hope to those in need.</p>
        <p class="thank-you-message">Every contribution makes a difference. We truly appreciate your support.</p>
        <button class="close-btn" onclick="closeThankYou()">Close</button>
    </div>
</div>

<script>
function showThankYou() {
    var popup = document.getElementById('thankYouPopup');
    popup.style.display = 'flex';
    createConfetti();
}

function closeThankYou() {
    var popup = document.getElementById('thankYouPopup');
    popup.style.display = 'none';
    var confettiContainer = document.getElementById('confetti-container');
    confettiContainer.innerHTML = '';
}

function createConfetti() {
    var confettiContainer = document.getElementById('confetti-container');
    confettiContainer.innerHTML = '';
    
    var colors = ['#ff4c4c', '#4CAF50', '#3498db', '#ffd700', '#ff6b9d', '#9b59b6', '#1abc9c'];
    var confettiCount = 100;
    
    for (var i = 0; i < confettiCount; i++) {
        var confetti = document.createElement('div');
        confetti.className = 'confetti';
        
        var randomColor = colors[Math.floor(Math.random() * colors.length)];
        confetti.style.backgroundColor = randomColor;
        
        var randomLeft = Math.random() * 100;
        var randomDelay = Math.random() * 2;
        var randomDuration = 2 + Math.random() * 3;
        var randomRotation = Math.random() * 360;
        
        confetti.style.left = randomLeft + '%';
        confetti.style.animationDelay = randomDelay + 's';
        confetti.style.animationDuration = randomDuration + 's';
        confetti.style.transform = 'rotate(' + randomRotation + 'deg)';
        
        confettiContainer.appendChild(confetti);
    }
}
</script>

<footer>
  <div class="footer-container">

    <div class="footer-section contact">
      <h3>Contact Us</h3>
      <p>123 Main Street, City, Country</p>
      <p>Phone: +961 05 432 134</p>
      <p>Email: echoofhope@outlook.com</p>
    </div>

    <div class="footer-section newsletter">
      <h3>Subscribe</h3>
      <p>Get updates and news from our organization:</p>
      <form>
        <input type="email" placeholder="Enter your email">
        <button type="submit">Subscribe</button>
      </form>
    </div>

    <div class="footer-section social">
      <h3>Follow Us</h3>
      <div class="social-icons">
        <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
        <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
        <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
      </div>
    </div>

  </div>

  <hr>

  <div class="footer-bottom">
    <p>
      <a href="#">Privacy Policy</a> | 
      <a href="#">Terms & Conditions</a> | 
      <a href="#">Accessibility</a>
    </p>
    <p>© 2026 Organization Name. All rights reserved.</p>
  </div>
</footer>

</body>
</html>

