<?php
require_once 'config.php';

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error . "<br><br>Please check your database settings in config.php");
}

echo "<h2>Database Setup</h2>";
echo "<p>Setting up your database...</p>";

$sql = "CREATE DATABASE IF NOT EXISTS " . DB_NAME;
if ($conn->query($sql) === TRUE) {
    echo "✓ Database '" . DB_NAME . "' created or already exists.<br>";
} else {
    echo "❌ Error creating database: " . $conn->error . "<br>";
    $conn->close();
    exit;
}

$conn->select_db(DB_NAME);

$sql = "CREATE TABLE IF NOT EXISTS contacts (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "✓ Table 'contacts' created or already exists.<br>";
} else {
    echo "❌ Error creating table: " . $conn->error . "<br>";
}

$conn->close();

echo "<br><strong style='color: green;'>✓ Setup complete! You can now use the contact form.</strong><br><br>";
echo "<a href='contact.php' style='padding: 10px 20px; background: #3498db; color: white; text-decoration: none; border-radius: 5px;'>Go to Contact Page</a>";
?>
