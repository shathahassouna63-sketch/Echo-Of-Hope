<!DOCTYPE html>
<html>
<head>
<title>Echo of Hope</title>
<link rel="icon" type="image/png" href="icon.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<link rel="stylesheet" href="sample.css">

</head>

<body>
<header class="navbar">
  <div class="logo"> Echo of Hope </div> 
  <nav>
    <a href="sample.php" data key="Home">Home &gt;</a>
    <a href="search.php" data key="Search">Search &gt;</a>
    <a href="request.php" data key="Request Help">Request Help &gt;</a>
    <a href="about.php" data key="About Us">About Us &gt;</a>
    <a href="contact.php" data key="Contact">Contact &gt;</a>
	<a href="donate.php">Donate &gt; </a>
  </nav>
</header>

<!-- Hero Section -->
<section class="hero">
  <div class="hero-text">
    <h1>Echoing through the silence of war</h1>
    <p>Help us connect families, reunite friends and save lost souls.<br><br>
    Together, we bring hope.</p>
    <a href="#" id="report-btn" class="btn">Report a Missing Person</a>
  </div>
  <div class="hero-img">
    <img src="picture.jpeg" alt="Hero Image"> 
  </div>
</section>

<!-- Stats Section -->
<section class="stats">
  <div class="stat-box">
    <h2>100+</h2>
    <p>Active Cases</p>
  </div>

  <div class="stat-box">
    <h2>90%</h2>
    <p>Cases Updated Weekly</p>
  </div>

  <div class="stat-box">
    <h2>40+</h2>          
    <p>Volunteers</p>
  </div>
</section>

<!-- Report Section -->
<section class="report-section" id="report-section">
  <h2>Report a Missing Person</h2>
  <form class="report-form">
    <label>First Name</label>
    <input type="text" placeholder="Enter first name" required>

    <label>Last Name</label>
    <input type="text" placeholder="Enter last name" required>

    <label>Date of Birth</label>
    <input type="date" required>

    <label>Phone Number</label>
    <input type="tel" placeholder="+961..." required>

    <label>Additional Information</label>
    <textarea placeholder="Describe last known location, clothing, etc..." rows="4"></textarea>

    <label>Upload Picture</label>
    <input type="file" accept="image/*">

    <button type="submit" class="btn">Submit Report</button>
  </form>
</section>

<footer>
  <div class="footer-container">

    <div class="footer-section contact">
      <h3>Contact Us</h3>
      <p>123 Main Street, City, Country</p>
      <p>Phone: +961 05 432 134</p>
      <p>Email: echoofhope@outlook.com</p>
    </div>

    <div class="footer-section newsletter">
      <h3>Subscribe</h3>
      <p>Get updates and news from our organization:</p>
      <form>
        <input type="email" placeholder="Enter your email">
        <button type="submit">Subscribe</button>
      </form>
    </div>

    <div class="footer-section social">
      <h3>Follow Us</h3>
      <div class="social-icons">
        <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
        <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
        <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
      </div>
    </div>

  </div>

  <hr>

  <div class="footer-bottom">
    <p>
      <a href="#">Privacy Policy</a> | 
      <a href="#">Terms & Conditions</a> | 
      <a href="#">Accessibility</a>
    </p>
    <p>© 2026 Organization Name. All rights reserved.</p>
  </div>
</footer>


<script>
const reportBtn = document.getElementById("report-btn");
const reportSection = document.getElementById("report-section");

reportBtn.addEventListener("click", function(e){
  e.preventDefault();
  reportSection.classList.add("show");
  setTimeout(() => {
    reportSection.scrollIntoView({behavior: "smooth"});
  }, 50);
});
</script>
</body>
</html>

