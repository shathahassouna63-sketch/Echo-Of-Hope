<!DOCTYPE html>
<html>
<head>
<title>Echo of Hope </title>
<link rel="icon" type="image/png" href="icon.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<link rel="stylesheet" href="request.css">
</head>

<body>

<header class="navbar">
<div class="logo">Echo of Hope</div>
<nav>
<a href="sample.php">Home &gt;</a>
<a href="search.php">Search &gt;</a>
<a href="request.php">Request Help &gt;</a>
<a href="about.php">About Us &gt;</a>
<a href="contact.php">Contact &gt;</a>
<a href="donate.php">Donate &gt; </a>
</nav>
</header>

<div class="page">

<img src="photo.jpeg" alt="Support and hope" class="floating-img">

<div class="help">
<h1>Request Help</h1>
<p class="subtitle">You are not alone. We plan to stand with you.</p>

<div class="intro">
Whether you are seeking support or offering help, this space is here to connect people with care, guidance, and action.
</div>

<div class="cards">
<button onclick="personal()">Personal Help</button>
<button onclick="others()">Help for Others</button>
</div>

<section id="me" class="hidden">

<h2>Personal Help</h2>
<hr>
<p class="hint"> Please share your information so we can guide you to the right support. </p>

<form>
<label>Full Name</label>
<input type="text">

<label>Email</label>
<input type="email" required>

<label>Type of help needed:</label><br>
<input type="checkbox"> Emotional Support <br>
<input type="checkbox"> Medical Assistance <br>
<input type="checkbox"> Legal Help <br>
<input type="checkbox"> Search Assistance <br>

<button type="submit">Submit</button>
</form>
</section>

<section id="others" class="hidden">

<h2>Help for Others</h2>
<hr>
<p class="hint"> Your support can make a difference. Tell us how you would like to help. </p>

<form>
<label>Full Name</label>
<input type="text">

<label>Email</label>
<input type="email" required>

<label>Severity of the problem:</label><br>
<input type="radio" name="severity"> Low <br>
<input type="radio" name="severity"> Medium <br>
<input type="radio" name="severity"> High <br>
<input type="radio" name="severity"> Emergency <br> <br> 

<label>How would you like to help?</label>
<select>
<option>Provide information</option>
<option>Volunteer</option>
<option> Donate  </option>
<option>Share awareness</option>
</select>

<button type="submit">Submit</button>
</form>
</section>
</div>

</div>

<footer>
  <div class="footer-container">

    <div class="footer-section contact">
      <h3>Contact Us</h3>
      <p>123 Main Street, City, Country</p>
      <p>Phone: +961 05 432 134</p>
      <p>Email: echoofhope@outlook.com</p>
    </div>

    <div class="footer-section newsletter">
      <h3>Subscribe</h3>
      <p>Get updates and news from our organization:</p>
      <form>
        <input type="email" placeholder="Enter your email">
        <button type="submit">Subscribe</button>
      </form>
    </div>

    <div class="footer-section social">
      <h3>Follow Us</h3>
      <div class="social-icons">
        <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
        <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
        <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
      </div>
    </div>

  </div>

  <hr>

  <div class="footer-bottom">
    <p>
      <a href="#">Privacy Policy</a> | 
      <a href="#">Terms & Conditions</a> | 
      <a href="#">Accessibility</a>
    </p>
    <p>© 2026 Organization Name. All rights reserved.</p>
  </div>
</footer>


<script>
  function personal() {
    document.getElementById("me").classList.remove("hidden");
    document.getElementById("others").classList.add("hidden");
  }

  function others() {
    document.getElementById("others").classList.remove("hidden");
    document.getElementById("me").classList.add("hidden");
  }
</script>

</body>
</html>

