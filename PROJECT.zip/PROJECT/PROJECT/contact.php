<?php
session_start();
require_once 'config.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Contact Us | Echo of Hope</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="contact.css">
    
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    
    <style>
        .g-recaptcha iframe,
        .g-recaptcha div {
            border: none !important;
        }
        
        .grecaptcha-badge,
        .rc-anchor-error-msg,
        .rc-anchor-error,
        .rc-anchor-error-content,
        .rc-anchor-error-message,
        .rc-anchor-error-text,
        [class*="error"],
        [id*="error"] {
            display: none !important;
            visibility: hidden !important;
            opacity: 0 !important;
        }
        
        #recaptcha-container * {
            color: inherit !important;
        }
        
        .g-recaptcha span[style*="color: red"],
        .g-recaptcha div[style*="color: red"],
        .g-recaptcha *[style*="color:red"],
        .g-recaptcha *[style*="color: red"] {
            display: none !important;
        }
        
        .recaptcha-warning {
            display: none;
            color: #dc3545;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 14px;
        }
        
        .recaptcha-warning.show {
            display: block;
        }
    </style>
</head>
<body>

<header class="navbar">
<div class="logo">Echo of Hope</div>
<nav>
<a href="sample.php">Home &gt;</a>
<a href="search.php">Search &gt;</a>
<a href="request.php">Request Help &gt;</a>
<a href="about.php">About Us &gt;</a>
<a href="contact.php">Contact &gt;</a>
<a href="donate.php">Donate &gt; </a>
</nav>
</header>

<div class="contact-container">

    <div class="logo">
        <h1>Echo of Hope</h1>
    </div>

    <h2>Have a question or concern?</h2>
    <p class="subtitle">We are happy to help.</p>

    <?php if (isset($_SESSION['message'])): ?>
        <div style="padding: 15px; margin-bottom: 20px; border-radius: 6px; background-color: <?php echo $_SESSION['message_type'] == 'success' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $_SESSION['message_type'] == 'success' ? '#155724' : '#721c24'; ?>;">
            <?php 
            echo $_SESSION['message'];
            unset($_SESSION['message']);
            unset($_SESSION['message_type']);
            ?>
        </div>
    <?php endif; ?>

    <div class="quick-question">
        <input type="text" placeholder="What is your question?" />
        <button>Send</button>
    </div>

    <div class="social-box">
        <h3>Reach us on social media</h3>
        <div class="social-icons">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-x-twitter"></i></a>
        </div>
    </div>

    <div class="info-box">
        <p><strong>Email:</strong> echoofhope@outlook.com</p>
        <p><strong>Phone:</strong> +961 05 432 134</p>
        <p class="small-text">
            Leave us a message or call, and we will return your answers within a few days.
        </p>
    </div>

    <form class="contact-form" method="POST" action="process_contact.php">
        <h3>Send Us a Message</h3>

        <div class="form-row">
            <input type="text" name="first_name" placeholder="First Name" required>
            <input type="text" name="last_name" placeholder="Last Name" required>
        </div>

        <input type="email" name="email" placeholder="Your Email Address" required>

        <textarea name="message" rows="5" placeholder="Your Message" required></textarea>

        <?php if (RECAPTCHA_SITE_KEY != 'YOUR_SITE_KEY' && RECAPTCHA_SITE_KEY != ''): ?>
            <div id="recaptcha-warning" class="recaptcha-warning">
                <strong>⚠️ Warning:</strong> Please complete the "I'm not a robot" verification before submitting.
            </div>
            
            <div style="margin-bottom: 15px; display: flex; justify-content: flex-start;">
                <div id="recaptcha-container" class="g-recaptcha" 
                     data-sitekey="<?php echo htmlspecialchars(RECAPTCHA_SITE_KEY); ?>"
                     data-theme="light"
                     data-size="normal">
                </div>
            </div>
        <?php else: ?>
            <div style="padding: 15px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 6px; margin-bottom: 15px;">
                <strong>⚠️ reCAPTCHA Not Configured</strong><br>
                <small>Please add your reCAPTCHA keys in <code>config.php</code>. 
                <a href="https://www.google.com/recaptcha/admin" target="_blank">Get keys here</a></small>
            </div>
        <?php endif; ?>

        <button type="submit" class="send-btn" id="submit-btn">Send Message</button>
        
        <script>
            window.addEventListener('load', function() {
                var form = document.querySelector('.contact-form');
                var warningDiv = document.getElementById('recaptcha-warning');
                var recaptchaContainer = document.getElementById('recaptcha-container');
                
                if (!form) return;
                
                form.addEventListener('submit', function(e) {
                    if (typeof grecaptcha === 'undefined') {
                        e.preventDefault();
                        if (warningDiv) {
                            warningDiv.textContent = '⚠️ Warning: reCAPTCHA is loading. Please wait a moment and try again.';
                            warningDiv.classList.add('show');
                        }
                        return false;
                    }
                    
                    var recaptchaResponse = grecaptcha.getResponse();
                    
                    if (!recaptchaResponse || recaptchaResponse.length === 0) {
                        e.preventDefault();
                        
                        if (warningDiv) {
                            warningDiv.innerHTML = '<strong>⚠️ Warning:</strong> Please complete the "I\'m not a robot" verification before submitting.';
                            warningDiv.classList.add('show');
                            warningDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                        }
                        
                        if (recaptchaContainer) {
                            recaptchaContainer.style.border = '2px solid #dc3545';
                            recaptchaContainer.style.borderRadius = '4px';
                            recaptchaContainer.style.padding = '5px';
                            
                            setTimeout(function() {
                                if (recaptchaContainer) {
                                    recaptchaContainer.style.border = '';
                                    recaptchaContainer.style.borderRadius = '';
                                    recaptchaContainer.style.padding = '';
                                }
                            }, 3000);
                        }
                        
                        return false;
                    } else {
                        if (warningDiv) {
                            warningDiv.classList.remove('show');
                        }
                    }
                });
                
                function onRecaptchaSuccess() {
                    if (warningDiv) {
                        warningDiv.classList.remove('show');
                    }
                    if (recaptchaContainer) {
                        recaptchaContainer.style.border = '';
                        recaptchaContainer.style.borderRadius = '';
                        recaptchaContainer.style.padding = '';
                    }
                }
                
                var checkInterval = setInterval(function() {
                    if (typeof grecaptcha !== 'undefined') {
                        try {
                            var recaptchaResponse = grecaptcha.getResponse();
                            if (recaptchaResponse && recaptchaResponse.length > 0) {
                                onRecaptchaSuccess();
                            }
                        } catch (e) {
                        }
                    }
                }, 500);
            });
        </script>
    </form>

</div>

<footer>
  <div class="footer-container">

    <div class="footer-section contact">
      <h3>Contact Us</h3>
      <p>123 Main Street, City, Country</p>
      <p>Phone: +961 05 432 134</p>
      <p>Email: echoofhope@outlook.com</p>
    </div>

    <div class="footer-section newsletter">
      <h3>Subscribe</h3>
      <p>Get updates and news from our organization:</p>
      <form>
        <input type="email" placeholder="Enter your email">
        <button type="submit">Subscribe</button>
      </form>
    </div>

    <div class="footer-section social">
      <h3>Follow Us</h3>
      <div class="social-icons">
        <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
        <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
        <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
      </div>
    </div>

  </div>

  <hr>

  <div class="footer-bottom">
    <p>
      <a href="#">Privacy Policy</a> | 
      <a href="#">Terms & Conditions</a> | 
      <a href="#">Accessibility</a>
    </p>
    <p>© 2026 Organization Name. All rights reserved.</p>
  </div>
</footer>

</body>
</html>
