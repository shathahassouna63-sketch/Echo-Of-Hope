<!DOCTYPE html>
<html>
<head>
<title> Echo of Hope </title>
<link rel="icon" type="1/jpeg" href="icon.jpeg"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<link rel="stylesheet" href="search.css">

</head>

<body>

<header class="navbar">
<div class="logo">Echo of Hope</div> 
<nav>
<a href="sample.php">Home &gt;</a>
<a href="search.php">Search &gt;</a>
<a href="request.php">Request Help &gt;</a>
<a href="about.php">About Us &gt;</a>
<a href="contact.php">Contact &gt;</a>
<a href="donate.php">Donate &gt; </a>
</nav>
</header>

<section class="search-section">
<h1>Search for a Missing Person</h1>
<p>Enter any information you have to locate a missing person</p>

<form id="searchForm">
<input type="text" id="nameInput" placeholder="full name">
<input type="number" id="ageInput" placeholder="age">

<select id="genderInput">
<option value="">Gender</option>
<option>Male</option>
<option>Female</option>
</select>

<input type="text" id="locationInput" placeholder="last seen">

<button type="submit" class="S-B">Search</button> 
</form>
</section> 

<section class="results" id="resultsSection" style="display:none;">
<h2>Search Results</h2>

<p id="noResults" style="display:none; text-align:center; color:#777;">
No results found
</p>

<div class="r-c" data-name="Abu Ahmad Khalil" data-age="72" data-gender="male" data-location="Beirut">
<img src="man2.jpeg">
<div>
<h3>Abu Ahmad Khalil</h3>
<p>Age: 72</p>
<p>Last seen: Beirut</p>
</div>
</div>

<div class="r-c" data-name="Sarah Hasan" data-age="7" data-gender="female" data-location="Tyre">
<img src="child.jpeg">
<div>
<h3>Sarah Hasan</h3>
<p>Age: 7</p>
<p>Last seen: Tyre</p>
</div>
</div>

<div class="r-c" data-name="Rayan Fadi" data-age="27" data-gender="male" data-location="Yaroun">
<img src="man.jpeg">
<div>
<h3>Rayan Fadi</h3>
<p>Age: 27</p>
<p>Last seen: Yaroun</p>
</div>
</div>

<div class="r-c" data-name="Zein Yousef" data-age="10" data-gender="male" data-location="baalbek">
<img src="child2.jpeg">
<div>
<h3>Zein Yousef</h3>
<p>Age: 10</p>
<p>Last seen: Baalbek</p>
</div>
</div>

<div class="r-c" data-name="Hala Saad" data-age="21" data-gender="female" data-location="bint jbeil">
<img src="woman2.jpeg">
<div>
<h3>Hala Saad</h3>
<p>Age: 21</p>
<p>Last seen: Bint Jbeil</p>
</div>
</div>

<div class="r-c" data-name="Samah Khalil" data-age="65" data-gender="female" data-location="Beirut's southern suburbs">
<img src="woman.jpeg">
<div>
<h3>Samah Khalil</h3>
<p>Age: 65</p>
<p>Last seen: southern suburbs</p>
</div>
</div>
</section>

<footer>
  <div class="footer-container">

    <div class="footer-section contact">
      <h3>Contact Us</h3>
      <p>123 Main Street, City, Country</p>
      <p>Phone: +961 05 432 134</p>
      <p>Email: echoofhope@outlook.com</p>
    </div>

    <div class="footer-section newsletter">
      <h3>Subscribe</h3>
      <p>Get updates and news from our organization:</p>
      <form>
        <input type="email" placeholder="Enter your email">
        <button type="submit">Subscribe</button>
      </form>
    </div>

    <div class="footer-section social">
      <h3>Follow Us</h3>
      <div class="social-icons">
        <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
        <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
        <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="https://www.linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
      </div>
    </div>

  </div>

  <hr>

  <div class="footer-bottom">
    <p>
      <a href="#">Privacy Policy</a> | 
      <a href="#">Terms & Conditions</a> | 
      <a href="#">Accessibility</a>
    </p>
    <p>© 2026 Organization Name. All rights reserved.</p>
  </div>
</footer>




<script>
document.getElementById("searchForm").addEventListener("submit", function(e) {
    e.preventDefault();

    let name = document.getElementById("nameInput").value.toLowerCase().trim();
    let age = document.getElementById("ageInput").value.trim();
    let gender = document.getElementById("genderInput").value.toLowerCase().trim();
    let location = document.getElementById("locationInput").value.toLowerCase().trim();

    if (!name && !age && !gender && !location) {
        return;
    }

    let resultsSection = document.getElementById("resultsSection");
    resultsSection.style.display = "block";

    let cards = document.querySelectorAll(".r-c");
    let found = false;

    cards.forEach(card => {
        let cardName = card.dataset.name.toLowerCase();
        let cardAge = card.dataset.age.toString();
        let cardGender = card.dataset.gender.toLowerCase();
        let cardLocation = card.dataset.location.toLowerCase();

        let match =
            (!name || cardName.includes(name)) &&
            (!age || cardAge === age) &&
            (!gender || cardGender === gender) &&
            (!location || cardLocation.includes(location));

        card.style.display = match ? "flex" : "none";
        if (match) found = true;
    });

    document.getElementById("noResults").style.display = found ? "none" : "block";
});
</script>

</body>
</html>

